/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export default function App() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-[#111111] rounded-lg border border-neutral-800 shadow-2xl overflow-hidden font-mono text-sm">
        
        {/* Terminal Header */}
        <div className="bg-[#1a1a1a] border-b border-neutral-800 p-3 flex items-center gap-2">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
            <div className="w-3 h-3 rounded-full bg-green-500/80"></div>
          </div>
          <div className="ml-4 text-neutral-500 text-xs">Entropic UI — CLI Installer</div>
        </div>

        {/* Terminal Body */}
        <div className="p-6 text-neutral-300 space-y-4">
          <div>
            <span className="text-green-400">~/projects/entropic-ui</span> <span className="text-pink-400">$</span> ls
          </div>
          <div className="text-neutral-400">
            AGENTS.md   <span className="text-green-300 font-semibold">cli.js</span>   package.json   src/   vite.config.ts
          </div>
          
          <div className="pt-2">
            <span className="text-green-400">~/projects/entropic-ui</span> <span className="text-pink-400">$</span> cat package.json | grep bin -A 2
          </div>
          <div className="text-neutral-400">
            &nbsp;&nbsp;"bin": &#123;<br/>
            &nbsp;&nbsp;&nbsp;&nbsp;"entropic-cli": "./cli.js"<br/>
            &nbsp;&nbsp;&#125;
          </div>

          <div className="pt-2">
            <span className="text-green-400">~/projects/entropic-ui</span> <span className="text-pink-400">$</span> <span className="text-blue-300"># Install the CLI locally</span>
          </div>
          <div>
            npm install -g .
          </div>

          <div className="pt-2">
            <span className="text-green-400">~/projects/entropic-ui</span> <span className="text-pink-400">$</span> <span className="text-blue-300"># Run the interactive designer</span>
          </div>
          <div>
            entropic-cli
          </div>
          
          <div className="pt-4 pb-2">
            <div className="bg-black/50 border border-neutral-700/50 p-4 rounded text-neutral-400">
              <div className="text-white bg-white/10 inline-block px-2 py-0.5 rounded text-xs mb-2 backdrop-blur">ENTROPIC UI v2.0 DESIGN SYSTEM INSTALLER</div>
              <div className="mt-2"><span className="text-green-400">?</span> Select your Core Theme (Color Palette):</div>
              <div className="text-neutral-500 pl-4">○ Entropic <span className="text-neutral-600 text-xs">Green / Purple / Amber</span></div>
              <div className="text-neutral-500 pl-4">○ Neon Cherry <span className="text-neutral-600 text-xs">Hot Pink / Mango / Aqua</span></div>
              <div className="text-cyan-400 pl-4">● Cobalt <span className="text-neutral-500 text-xs">Electric Blue / Yellow / Red</span></div>
              <div className="text-neutral-500 pl-4">○ SolarStorm <span className="text-neutral-600 text-xs">Electric Yellow / White / Black</span></div>
            </div>
          </div>
          
          <div className="text-neutral-500 animate-pulse">_</div>
        </div>

      </div>
    </div>
  );
}
