#!/usr/bin/env node

import { intro, outro, select, spinner, text } from '@clack/prompts';
import pc from 'picocolors';
import fs from 'fs/promises';
import path from 'path';

// CSS Templates for the 15 combinations and base styles
// For brevity and to fit the design system, we will generate the appropriate CSS
// variables dynamically based on the selections.

const THEMES = {
  entropic: {
    primary: '#03ff6c',
    accent1: '#7cfc19',
    accent2: '#ffa805',
    accent3: '#5b0af2',
    gradText: 'linear-gradient(135deg, #03ff6c 0%, #7cfc19 40%, #c4fc19 70%, #ffa805 100%)',
    darkBg: '#000000',
    lightBg: '#f0faf4',
    gridColor: 'rgba(3,255,108,0.035)',
    btnText: '#000000'
  },
  cherry: {
    primary: '#ff0066',
    accent1: '#ff8c00',
    accent2: '#00ffaa',
    accent3: '#ff44aa',
    gradText: 'linear-gradient(135deg, #ff0066 0%, #ff4488 30%, #ff8c00 70%, #ffb300 100%)',
    darkBg: '#000000',
    lightBg: '#fff0f5',
    gridColor: 'rgba(255,0,102,0.035)',
    btnText: '#ffffff'
  },
  jungle: {
    primary: '#aaff00',
    accent1: '#00e066',
    accent2: '#00ffcc',
    accent3: '#f71e5b',
    gradText: 'linear-gradient(135deg, #aaff00 0%, #66ff33 45%, #00ffcc 80%, #00e0aa 100%)',
    darkBg: '#000000',
    lightBg: '#f4fff0',
    gridColor: 'rgba(170,255,0,0.035)',
    btnText: '#000000'
  },
  cobalt: {
    primary: '#0088ff',
    accent1: '#ffdd00',
    accent2: '#ff2200',
    accent3: '#8800ff',
    gradText: 'linear-gradient(135deg, #0066ff 0%, #3344ff 35%, #6633ff 65%, #8800cc 88%, #0099ff 100%)',
    darkBg: '#050810',
    lightBg: '#f0f4ff',
    gridColor: 'rgba(0,136,255,0.035)',
    btnText: '#ffffff'
  },
  solar: {
    primary: '#fbff03',
    accent1: '#e2ff03',
    accent2: '#ffffff',
    accent3: '#33332f',
    gradText: 'linear-gradient(135deg, #fbff03 0%, #e2ff03 50%, #ffffff 100%)',
    darkBg: '#000000',
    lightBg: '#fffff0',
    gridColor: 'rgba(251,255,3,0.035)',
    btnText: '#000000'
  }
};

const VARIANTS = {
  liquid: {
    glassBlur: 'blur(28px) saturate(200%) brightness(112%)',
    glassRadius: '20px',
    btnRadius: '100px',
    hoverLift: 'translateY(-5px)',
    transition: '0.22s ease',
    heroTracking: '-0.04em',
    sectionPad: '100px',
    gridSize: '80px',
    gridOpacity: '0.04',
    rimOpacity: '0.28',
    bodyFont: '"Inter", sans-serif',
    displayFont: '"Inter", sans-serif',
    bodyWeight: '400',
    glassBgRest: 'rgba(255, 255, 255, 0.04)',
    glassBgLight: 'rgba(255,255,255,0.55)',
  },
  brutal: {
    glassBlur: 'blur(8px) saturate(140%)',
    glassRadius: '4px',
    btnRadius: '2px',
    hoverLift: 'translateY(0)',
    transition: '0.08s ease',
    heroTracking: '0em',
    sectionPad: '56px',
    gridSize: '40px',
    gridOpacity: '0.07',
    rimOpacity: '0.10',
    bodyFont: '"JetBrains Mono", monospace',
    displayFont: '"Orbitron", monospace',
    bodyWeight: '400',
    glassBgRest: 'rgba(255, 255, 255, 0.04)',
    glassBgLight: 'rgba(255,255,255,0.55)',
  },
  minimal: {
    glassBlur: 'blur(16px) saturate(160%)',
    glassRadius: '12px',
    btnRadius: '8px',
    hoverLift: 'translateY(0)',
    transition: '0.35s cubic-bezier(0.25,0.46,0.45,0.94)',
    heroTracking: '-0.05em',
    sectionPad: '160px',
    gridSize: '80px',
    gridOpacity: '0',
    rimOpacity: '0',
    bodyFont: '"Inter", sans-serif',
    displayFont: '"Inter", sans-serif',
    bodyWeight: '300',
    glassBgRest: 'rgba(255, 255, 255, 0)',
    glassBgLight: 'rgba(255,255,255,0)',
  }
};

async function main() {
  console.clear();
  intro(pc.inverse(' ENTROPIC UI v2.0 DESIGN SYSTEM INSTALLER '));

  const themeSelection = await select({
    message: 'Select your Core Theme (Color Palette):',
    options: [
      { value: 'entropic', label: 'Entropic', hint: 'Green / Purple / Amber' },
      { value: 'cherry', label: 'Neon Cherry', hint: 'Hot Pink / Mango / Aqua' },
      { value: 'jungle', label: 'Neon Jungle', hint: 'Yellow-Green / Aqua / Crimson' },
      { value: 'cobalt', label: 'Cobalt', hint: 'Electric Blue / Yellow / Red' },
      { value: 'solar', label: 'SolarStorm', hint: 'Electric Yellow / White / Black' }
    ]
  });

  if (themeSelection === null) return;

  const variantSelection = await select({
    message: 'Select your Style Variant (Form & Depth):',
    options: [
      { value: 'liquid', label: 'Liquid', hint: 'Deep blur, floating orbs, heavy rims, max immersion.' },
      { value: 'brutal', label: 'Brutalist Glass', hint: 'Sharp geometry, grid overlays, Orbitron headings.' },
      { value: 'minimal', label: 'Neo-Minimal', hint: 'Invisible at rest, reveals on hover, max whitespace.' }
    ]
  });

  if (variantSelection === null) return;

  const outputDir = await text({
    message: 'Output directory for CSS (defaults to .):',
    placeholder: '.',
    defaultValue: '.'
  });

  if (outputDir === null) return;

  const t = THEMES[themeSelection];
  const v = VARIANTS[variantSelection];

  const s = spinner();
  s.start('Synthesizing stylesheet...');

  await new Promise(resolve => setTimeout(resolve, 800));

  const cssContent = `/* ENTROPIC UI v2.0
 * Theme: ${themeSelection.toUpperCase()}
 * Variant: ${variantSelection.toUpperCase()}
 * Auto-generated by Entropic CLI
 */

:root {
  /* Colors */
  --primary: ${t.primary};
  --accent1: ${t.accent1};
  --accent2: ${t.accent2};
  --accent3: ${t.accent3};
  --grad-text: ${t.gradText};
  
  --bg: ${t.darkBg};
  --text: rgba(255, 255, 255, 0.88);
  --grid-color: ${t.gridColor};
  
  /* Variant Tokens */
  --glass-blur: ${v.glassBlur};
  --glass-radius: ${v.glassRadius};
  --btn-radius: ${v.btnRadius};
  --hover-lift: ${v.hoverLift};
  --transition: ${v.transition};
  --hero-tracking: ${v.heroTracking};
  --section-pad: ${v.sectionPad};
  --grid-size: ${v.gridSize};
  --grid-opacity: ${v.gridOpacity};
  --rim-opacity: ${v.rimOpacity};
  
  --body-font: ${v.bodyFont};
  --display-font: ${v.displayFont};
  --body-weight: ${v.bodyWeight};
  
  --glass-bg: ${v.glassBgRest};
  --btn-text: ${t.btnText};
}

.theme-light {
  --bg: ${t.lightBg};
  --text: rgba(0, 20, 8, 0.88);
  --glass-bg: ${v.glassBgLight};
}

/* Base Rules */
body {
  background-color: var(--bg);
  color: var(--text);
  font-family: var(--body-font);
  font-weight: var(--body-weight);
  margin: 0;
  transition: background-color var(--transition), color var(--transition);
}

h1, h2, h3, h4 {
  font-family: var(--display-font);
  letter-spacing: var(--hero-tracking);
}

.glass {
  background: var(--glass-bg);
  backdrop-filter: var(--glass-blur);
  -webkit-backdrop-filter: var(--glass-blur);
  border-radius: var(--glass-radius);
  border: 1px solid rgba(255, 255, 255, 0.08);
  position: relative;
  transition: all var(--transition);
}

${variantSelection === 'liquid' ? `
.glass::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, var(--primary), transparent);
  opacity: var(--rim-opacity);
}
` : ''}

.glass:hover {
  transform: var(--hover-lift);
  ${variantSelection === 'minimal' ? 'background: rgba(255,255,255,0.04);' : ''}
}
`;

  const fileName = `${variantSelection}-${themeSelection}.css`;
  const filePath = path.join(process.cwd(), outputDir, fileName);

  try {
    await fs.mkdir(path.join(process.cwd(), outputDir), { recursive: true });
    await fs.writeFile(filePath, cssContent, 'utf8');
    s.stop(`Stylesheet written to ${pc.green(path.relative(process.cwd(), filePath))}`);

    outro(`
${pc.bold('HTML Integration:')}
Include the following tags in your document head:

${pc.cyan(variantSelection === 'brutal' ? 
  `<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&family=JetBrains+Mono:wght@400&display=swap" rel="stylesheet">\n<link rel="stylesheet" href="${fileName}">` : 
  `<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">\n<link rel="stylesheet" href="${fileName}">`)}

Next steps: Design with the new physical interface!
`);
  } catch (err) {
    s.stop(pc.red('Failed to write stylesheet'));
    console.error(err);
  }
}

main().catch(console.error);
