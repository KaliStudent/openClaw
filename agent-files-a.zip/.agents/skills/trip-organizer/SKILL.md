---
name: trip-organizer
description: Pull travel confirmations from your inbox and assemble them into a clean chronological itinerary (flights, hotels, car rentals) and flag things like tight connections, hotel gaps, and missing return legs.
---

# Trip Organizer

The outcome is simple: one clean itinerary the traveler can glance at, instead of scrolling through twelve confirmation emails while standing at the gate. You do the digging once, in advance, so nobody is reconstructing their day from memory at an airport.

**Talking to the user:** Be calm and logistical. Travelers are often stressed and short on time, so lead with the assembled itinerary, not questions.

## Golden Rule

Assemble a real itinerary first from whatever confirmations you can find, then present it. Don't open with a checklist of questions. The value is in seeing the whole trip laid out — produce that, flag what's uncertain, and only ask when something genuinely can't be resolved.

## Core method

1. **Find the travel confirmations.** Search the inbox for flights, hotels, trains, and car rentals — including ones forwarded by an assistant, partner, or travel agent. Recognition signals: senders that are airlines, hotel chains, booking sites (Expedia, Booking.com), or rail/rental brands; subject lines with "confirmation," "itinerary," "booking," "e-ticket," or "reservation"; and body text containing PNR / record-locator codes (six-character alphanumerics like `K8X2QP`), confirmation numbers, or flight numbers. Forwarded mail often buries the real sender, so read the body, not just the From line.

2. **Extract details accurately.** For each segment pull dates, times, **timezones**, confirmation/record-locator numbers, and addresses (hotel street address, airport, station, rental pickup location). Timezones matter more here than anywhere else: a flight that departs 9:00 AM local and lands "1:00 PM" can cross zones, and a hotel check-in is in the hotel's local time, not the traveler's home time. Always capture and display the timezone explicitly, and never silently convert or assume one — if a confirmation doesn't state it, say so rather than guessing. Never fabricate a time, gate, or confirmation number; if a field is missing or ambiguous, mark it as unconfirmed.

3. **Assemble and flag.** Sort everything chronologically into one itinerary per trip, then proactively scan for the problems travelers miss — this is the highest-value part of the job:
   - **Tight connections:** a layover too short to realistically make (flag anything under ~60 min international, ~45 min domestic, and call out terminal changes).
   - **Hotel gaps:** a night with no lodging booked — e.g., arriving the 12th but the hotel only covers the 13th onward.
   - **Check-in / flight conflicts:** a hotel checkout or check-in time that collides with a flight, or a meeting the trip can't physically make.
   - **Missing segments:** an outbound with no return, or a leg that lands in one city while the next departs from another with no transport between them.
   Surface these clearly; they're exactly what gets overlooked until it's too late to fix cheaply.

## Output Format

A chronological itinerary grouped by trip. Each segment shows: date and start time **with timezone**, what it is, the confirmation number, and the location.

> **SF Trip — Mar 12–15**
>
> - **Mar 12, 8:40 AM PST** — Flight UA 215, SFO → arrives 8:40 AM PST. Conf: `K8X2QP`
> - **Mar 12, 3:00 PM PST** — Hotel check-in, Hotel Zephyr, 250 Beach St. Conf: `HZ-44192`
> - **Mar 15, 11:00 AM PST** — Hotel checkout
> - **Mar 15, 6:15 PM PST** — Flight UA 388, SFO → JFK, lands 2:40 AM EST. Conf: `K8X2QP`
>
> **Heads up**
> - No lodging booked for the night of Mar 14 — hotel only covers the 12th–13th.
> - The return on Mar 15 departs 6:15 PM but checkout is 11:00 AM; you'll have ~7 hours to fill.

If nothing needs flagging, say the trip looks clean — that reassurance is worth stating.

## Tooling

Needs read-only email access to find confirmations. Read-only is the whole posture here: never cancel, change, rebook, or contact anyone about a booking. You organize and flag; the traveler decides what to act on.

## Iterating

Keep follow-ups cheap:
- "Just the next trip" — show only the soonest upcoming itinerary.
- "Add this one" — fold in a confirmation the user pastes or forwards manually.
- "Local time only" — drop the home-timezone conversions and show each segment in its own local time.

## Recurring Use

Offer to keep a living upcoming-trips itinerary that refreshes as new confirmations land in the inbox — so a hotel booked next week or a seat change tomorrow shows up automatically, and the traveler always has one current view instead of re-running the whole search.

## Examples

**"What's my schedule for the SF trip?"** → Find the SFO/SF confirmations, assemble the chronological itinerary above, and lead with any heads-up flags.

**"Pull my flight and hotel confirmations together for next month."** → Group everything in that window by trip, present each as its own itinerary block, and note any trip with a missing return or hotel gap.

**"Track my bookings."** → Build the current itinerary, then offer to keep it updated as new confirmations arrive (Recurring Use).