---
name: contract-review
description: Review contracts against your organization's negotiation playbook, flagging deviations and generating redline suggestions. Use when reviewing vendor contracts, customer agreements, or any commercial agreement where you need clause-by-clause analysis against standard positions.
---

Review contracts against a negotiation playbook, generate redline suggestions for compliance.