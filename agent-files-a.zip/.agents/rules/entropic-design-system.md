# ENTROPIC UI — Design System
*Liquid Glass / Dark Immersive / Form-Factor Agnostic*
*Version 2.0 — May 2026*

---

## CORE PHILOSOPHY

Build interfaces that feel alive. Glass lives on the chrome layer, not on primary content. Every surface should respond to what's behind and beneath it. Dark-first, always. Motion should feel physical, not decorative.

---

## STYLESHEET DISTRIBUTION

As of v2.0, all 15 theme×style combinations are distributed as standalone CSS files. Each file is fully self-contained (reset, tokens, utilities, style-specific overrides) and ships with both dark and light mode via `.theme-dark` (default) and `.theme-light` class.

**File naming convention:** `{style}-{theme}.css`

| Style \ Theme | Entropic | Cherry | Jungle | Cobalt | Solar |
|---|---|---|---|---|---|
| **liquid** | liquid-entropic.css | liquid-cherry.css | liquid-jungle.css | liquid-cobalt.css | liquid-solar.css |
| **brutal** | brutal-entropic.css | brutal-cherry.css | brutal-jungle.css | brutal-cobalt.css | brutal-solar.css |
| **minimal** | minimal-entropic.css | minimal-cherry.css | minimal-jungle.css | minimal-cobalt.css | minimal-solar.css |

**Usage:**
```html
<!-- 1. Google Fonts (liquid/minimal = Inter, brutal = JetBrains Mono + Orbitron) -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

<!-- 2. One stylesheet -->
<link rel="stylesheet" href="liquid-cobalt.css">

<!-- 3. Mode class on html or body (omit for dark default) -->
<body class="theme-light">
```

**CSS custom properties exposed (all files):**
`--primary` `--primary-lt` `--primary-dk` `--accent1` `--accent2` `--accent3`
`--grad-text` `--bg` `--surface` `--surface2` `--text` `--text-dim`
`--border` `--border2` `--primary-tint` `--primary-border` `--primary-rim`
`--orb1` `--orb2` `--orb3` `--grid-color` `--grid-size` `--grid-opacity`
`--glass-blur` `--glass-bg` `--glass-border` `--glass-radius` `--glass-shadow`
`--glass-shadow-hover` `--rim-opacity` `--btn-radius` `--btn-border` `--btn-bg`
`--btn-bg-hover` `--btn-glow-shadow` `--nav-bg` `--body-font` `--display-font`
`--hero-tracking` `--hero-weight` `--body-weight` `--section-pad`
`--hover-lift` `--transition`

---

## THEME SYSTEM

There are 5 official Entropic themes. All share the same black base, glass rules, motion principles, and layout system. Only the color palette swaps. When building, pick one theme and apply it consistently — never mix palettes across themes in the same composition.

---

## THEME 1 — ENTROPIC (Original)

The default. Electric green primary, purple depth, amber warmth.

- **Primary:** `#03ff6c` — electric green (main accent, glows, CTAs)
- **Accent 1:** `#7cfc19` / `#c4fc19` — chartreuse / yellow-green (gradient midpoints)
- **Accent 2:** `#ffa805` — amber/orange (warm accent, gradient endpoints)
- **Accent 3:** `#5b0af2` — deep purple (contrast, depth orbs)
- **Gradient text:** `linear-gradient(135deg, #03ff6c 0%, #7cfc19 40%, #c4fc19 70%, #ffa805 100%)`
- **Orbs:** green `rgba(3,255,108,0.20)`, purple `rgba(91,10,242,0.24)`, amber `rgba(255,168,5,0.14)`, chartreuse `rgba(196,252,25,0.12)`
- **Grid:** `rgba(3,255,108,0.035)`
- **Dark bg:** `#000000` | **Light bg:** `#f0faf4`

---

## THEME 2 — NEON CHERRY

Hot red-pink primary. Mango orange and aqua green accents. Maximum energy.

- **Primary:** `#ff0066` — neon cherry
- **Accent 1:** `#ff8c00` — mango orange
- **Accent 2:** `#00ffaa` — comfort green/aqua
- **Accent 3:** `#ff44aa` — hot pink
- **Gradient text:** `linear-gradient(135deg, #ff0066 0%, #ff4488 30%, #ff8c00 70%, #ffb300 100%)`
- **Dark bg:** `#000000` | **Light bg:** `#fff0f5`
- **Notes:** Highest visual impact. Consumer-facing, games, entertainment.

---

## THEME 3 — NEON JUNGLE

Neon yellow-green primary. Traditional green + aqua accents. Crimson-pink as the standout accent.

- **Primary:** `#aaff00` — neon yellow-green
- **Accent 1:** `#00e066` — traditional green
- **Accent 2:** `#00ffcc` — aqua-green
- **Accent 3:** `#f71e5b` — hot crimson-pink (primary CTA accent — use over green)
- **Gradient text:** `linear-gradient(135deg, #aaff00 0%, #66ff33 45%, #00ffcc 80%, #00e0aa 100%)`
- **Dark bg:** `#000000` | **Light bg:** `#f4fff0`
- **Notes:** Jungle is a variation of Entropic. The crimson-pink `#f71e5b` is the secret weapon.

---

## THEME 4 — COBALT

Electric blue primary. Blue-to-purple gradient. Yellow/red/purple as contextual functional accents.

- **Primary:** `#0088ff` — electric blue
- **Accent 1:** `#ffdd00` — traditional yellow
- **Accent 2:** `#ff2200` — traditional red
- **Accent 3:** `#8800ff` — deep purple
- **Gradient text:** `linear-gradient(135deg, #0066ff 0%, #3344ff 35%, #6633ff 65%, #8800cc 88%, #0099ff 100%)`
- **Dark bg:** `#050810` | **Light bg:** `#f0f4ff`

### Cobalt Contextual Button System

| Context | Color | Border | BG | Glow |
|---|---|---|---|---|
| Navigation / CTAs | `#0088ff` | `rgba(0,136,255,0.45)` | `rgba(0,136,255,0.09)` | `rgba(0,136,255,0.28)` |
| Forms & Input | `#ffdd00` | `rgba(255,221,0,0.45)` | `rgba(255,221,0,0.08)` | `rgba(255,221,0,0.25)` |
| Destructive / Alerts | `#ff2200` | `rgba(255,34,0,0.45)` | `rgba(255,34,0,0.08)` | `rgba(255,34,0,0.25)` |
| Settings / Account | `#8800ff` | `rgba(136,0,255,0.45)` | `rgba(136,0,255,0.08)` | `rgba(136,0,255,0.25)` |

---

## THEME 5 — SOLARSTORM

Pure black. Electric yellow-chartreuse primary. Designed for Brutalist Glass but valid across all variants.

- **Primary:** `#fbff03` — electric yellow-chartreuse
- **Accent 1:** `#e2ff03` — soft yellow-green (links, secondary highlights)
- **Accent 2:** `#ffffff` — pure white (text hierarchy, borders)
- **Accent 3:** `#33332f` — near-black warm dark (depth fills)
- **Gradient text:** `linear-gradient(135deg, #fbff03 0%, #e2ff03 50%, #ffffff 100%)`
- **Dark bg:** `#000000` | **Light bg:** `#fffff0`
- **Button text is always `#000000`** — black on yellow, never white.

---

## BASE COLORS (all themes)

- `#ffffff` `#d1d1d1` — whites/light grays (text, borders, highlights)
- `#000000` `#404040` — blacks/dark grays (backgrounds, depth)

---

## STYLE VARIANTS

Themes control **color**. Style variants control **form, depth, and motion**. Any theme × any variant is valid.

---

### VARIANT 1 — LIQUID

Maximum immersion. Deep blur, floating orbs, heavy specular rims, lift and glow on every interaction.

**Key tokens:**
```css
--glass-blur:    blur(28px) saturate(200%) brightness(112%);
--glass-radius:  20px;
--btn-radius:    100px;          /* pill */
--hover-lift:    translateY(-5px);
--transition:    0.22s ease;
--hero-tracking: -0.04em;
--section-pad:   100px;
--grid-size:     80px;
--grid-opacity:  0.04;
--rim-opacity:   0.28;
```

**Rules:**
- Orbs always animate. Never static in Liquid.
- Cards hover-lift `translateY(-5px)` with color glow.
- Top specular rim on every glass surface — mandatory.
- Buttons are pill-shaped always.
- Mouse-reactive ghost orb follows cursor with ~1.3s cubic-bezier lag.
- Background: custom canvas rain engine (condensation, gravity, refraction). No rainyday.js dependency.
- Rain canvas sits at z-index 1, orbs at z-index 2, content above.

---

### VARIANT 2 — BRUTALIST GLASS

Sharp geometry, harsh borders, no motion, grid always visible. Function over beauty — but still glass.

**Key tokens:**
```css
--glass-blur:    blur(8px) saturate(140%);
--glass-radius:  4px;
--btn-radius:    2px;
--hover-lift:    translateY(0);
--transition:    0.08s ease;
--hero-tracking: 0em;
--section-pad:   56px;
--grid-size:     40px;
--grid-opacity:  0.07;
--rim-opacity:   0.10;
--body-font:     'JetBrains Mono', monospace;
--display-font:  'Orbitron', monospace;
```

**Rules:**
- Orbs are paused — no animation.
- Glass hovers change border color to primary — no transform.
- Button hover = solid fill with primary color, black text.
- Grid is always visible and intentional — a design element, not decoration.
- Typography uses `Orbitron` for headings, `JetBrains Mono` for body.
- `glass::after` shimmer animation is disabled.
- SolarStorm Brutalist: button fill becomes `#fbff03`, text `#000000` — hazard sign energy.

---

### VARIANT 3 — NEO-MINIMAL

Invisible at rest. Everything reveals on interaction. Maximum whitespace.

**Key tokens:**
```css
--glass-blur:    blur(16px) saturate(160%);
--glass-radius:  12px;
--btn-radius:    8px;
--hover-lift:    translateY(0);
--transition:    0.35s cubic-bezier(0.25,0.46,0.45,0.94);
--hero-tracking: -0.05em;
--body-weight:   300;
--section-pad:   160px;
--grid-opacity:  0;
--rim-opacity:   0.0;
```

**Rules:**
- `.glass` is fully transparent at rest — background, border, blur all removed.
- On hover: glass background, blur, border, and shadow all activate.
- `.glass::before` rim is hidden at rest, appears on hover.
- `.btn` is transparent at rest, border appears on hover.
- Scroll-reveal: `.reveal` class starts at `opacity:0; transform:translateY(20px)`. Add `.visible` to activate.
- No grid overlay.
- Nav is transparent by default, gains blur/background on hover.
- Orbs animate at slower speed (32s+ durations).
- Extreme whitespace is the primary design element — don't fill the space.

---

## GLASS LAYER RULES (all variants)

1. **Glass on the chrome layer only** — nav, cards, modals, sidebars. Never on primary content text.
2. **One glass depth level per composition** — no glass-on-glass stacking.
3. **Two glass variants:**
   - **Regular** — `rgba(255,255,255,0.04)` bg — for cards, panels, any non-nav surface
   - **Clear** — `rgba(255,255,255,0.02)` bg — for overlays, backgrounds that should feel barely there
4. **Specular rim** — always `::before` pseudo-element, top edge, gradient left→primary→right.
5. **Bottom shimmer** — optional `::after` on cards, subtle animated gradient.

---

## LIGHT MODE RULES (v2.0 addition)

Every stylesheet ships with `.theme-light`. Key adaptations:

- Primary color darkens (e.g. `#03ff6c` → `#01cc55`) for contrast on light backgrounds.
- Surfaces flip: `#000` → theme-specific light bg (e.g. `#f0faf4` for Entropic).
- Glass bg increases opacity: `rgba(255,255,255,0.04)` → `rgba(255,255,255,0.55)`.
- Glass border adapts: dark `rgba(255,255,255,0.08)` → light `rgba(255,255,255,0.60)`.
- Border tokens flip: `rgba(255,255,255,0.08)` → `rgba(0,0,0,0.09)`.
- Text: dark `rgba(255,255,255,0.88)` → light `rgba(0,20,8,0.88)` (theme-tinted).
- SolarStorm light mode uses `#fffff0` (cream) background — pure white is too harsh with yellow.
- Grid color adjusts to remain subtle on light bg.

**Implementation:** Add `class="theme-light"` to `<html>` or `<body>`. Toggle dynamically for user preference.

---

## TYPOGRAPHY

### Liquid & Minimal
- **Body:** `'Inter'`, system-ui fallback
- **Display/Hero:** `'Inter'` at weight 900, tracking `-0.04em` (liquid) / `-0.05em` (minimal)
- **Body weight:** 400 (liquid) / 300 (minimal)

### Brutalist
- **Body:** `'JetBrains Mono'`, `'Fira Code'` fallback
- **Display/Hero:** `'Orbitron'`, `'JetBrains Mono'` fallback, weight 700-900
- **Body weight:** 400

### Hero scale (all variants)
```css
font-size: clamp(44px, 9vw, 110px);
line-height: 0.95;
```

---

## MOTION SYSTEM

### Liquid
- Orb drift: `entropic-drift1` 20-26s, `entropic-drift2` 22-28s — ease-in-out infinite
- Card hover lift: `translateY(-5px)` at `0.22s ease`
- Mouse orb lag: `1.3s cubic-bezier(0.25,0.46,0.45,0.94)`
- Shimmer: `entropic-shimmer` 8-10s ease-in-out infinite
- Pulse (badge dot): `entropic-pulse` 2s infinite

### Brutalist
- All orb animations paused
- Hover: instant color fill `0.08s ease`, no transform
- No shimmer, no pulse on non-functional elements

### Minimal
- Orbs slow: 30-32s duration
- Reveal: `opacity 0.7s` + `transform 0.7s` cubic-bezier
- Hover: slower `0.35s cubic-bezier(0.25,0.46,0.45,0.94)`

### Universal
```css
@keyframes entropic-pulse   { 0%,100%{opacity:1} 50%{opacity:0.3} }
@keyframes entropic-shimmer { 0%,100%{opacity:0.4} 50%{opacity:1} }
@keyframes entropic-float   { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-7px)} }
@keyframes entropic-drift1  { 0%{transform:translate(4vw,8vh)} ... }
@keyframes entropic-drift2  { 0%{transform:translate(48vw,18vh)} ... }
```

---

## LAYOUT SYSTEM

- **Max content width:** `1200px` centered
- **Section padding:** `var(--section-pad)` vertical + `clamp(16px,5vw,80px)` horizontal
- **Card gap:** `18px`
- **Nav height:** `60px` sticky
- **Responsive breakpoints:** mobile-first, `clamp()` for all type sizes

---

## UTILITY CLASSES

| Class | Description |
|---|---|
| `.glass` | Glass card — applies all glass tokens |
| `.btn` | Primary button |
| `.btn-ghost` | Ghost/secondary button |
| `.badge` | Small label badge with accent dot |
| `.badge-dot` | Animated pulse dot inside badge |
| `.grad-text` | Gradient text using `--grad-text` |
| `.nav` | Sticky nav bar |
| `.section` | Section wrapper with padding |
| `.section-eyebrow` | Small uppercase label above title |
| `.section-title` | Large section heading |
| `.section-sub` | Section subheading/description |
| `.grid-2` | Auto-fit 2-col grid (280px min) |
| `.grid-3` | Auto-fit 3-col grid (220px min) |
| `.divider` | 1px horizontal rule |
| `.orb` | Background glow orb (position yourself) |
| `.entropic-grid` | CSS background grid overlay |
| `.reveal` | Scroll reveal (minimal only) |

---

## RAIN ENGINE (Liquid variant)

The Liquid style uses a custom canvas-based condensation rain engine. Key characteristics:

- Camera is **behind a wet glass pane** — rain lands on the glass, not falling in front of the camera
- Drops accumulate, develop surface tension, then slide down leaving fading wet streaks
- Internal lens refraction: dark center with blue-tinted refraction gradient
- Specular glint: radial gradient at -35% / -45% offset simulating light source reflection
- Streaks: semi-transparent thin lines that fade segment by segment from the top
- Physics: `vy += 0.04 + r * 0.006`, capped at `5.5 + r * 0.3`
- Wobble: `sin(t) * r * 0.25` on x-axis during slide
- Canvas layer: `position:fixed`, `z-index:1`, behind orbs and content
- No external dependencies — fully self-contained canvas 2D

---

## PHOTOSHOP GLASS LAYER STACK

To recreate Entropic glass effects in Photoshop:

1. **Base layer** — solid fill at `rgba(255,255,255,0.04)` opacity
2. **Blur layer** — Smart Object with Gaussian Blur 28px + Hue/Saturation +40 saturation
3. **Top rim** — 1px line, gradient left→accent→right at 28-30% opacity, Screen blend
4. **Specular highlight** — radial gradient white→transparent, top-left, 15-20% opacity, Screen blend
5. **Bottom accent** — 1px line at bottom using accent3 color at 15% opacity
6. **Noise overlay** — Add Noise 3%, Monochromatic, Overlay blend at 8% opacity

---

## CHANGELOG

### v2.0 — May 2026
- Distributed as 15 standalone CSS files (all theme × style combinations)
- Added full light mode (`.theme-light`) to every stylesheet
- All files self-contained: reset + tokens + utilities + style overrides
- `color-mix()` used for primary tints — no hardcoded rgba variants
- Rain engine updated: removed rainyday.js dependency, replaced with custom canvas implementation
- Added `--glass-shadow-hover` token (separate from resting shadow)
- Added `--btn-bg-hover` token
- Documented `--primary-rim` as dedicated specular rim token
- Typography tokens expanded: `--hero-weight`, `--body-weight`, `--hero-tracking`
- SolarStorm light mode uses `#fffff0` cream base (not pure white)
- `_base.css` included in zip as reference/import utility

### v1.0 — March 2026
- Initial system: 5 themes × 3 style variants defined
- CSS custom property architecture established
- Orb animation system, rain engine, glass layer rules documented
